HQINVESTMENT HOTSPOT LOGIN PAGE
========================
Generated on: 28/03/2026, 22:32:43
Company: HQ INVESTMENT
Router: Test Router (192.168.88.1)

FILES INCLUDED:
- login.html
- alogin.html
- redirect.html
- api.json
- errors.txt
- WISPAaccessGatewaParam.xsd